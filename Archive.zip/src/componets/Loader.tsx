const Loader = () => {
    return <div className='spinner'></div>
}

export default Loader
